# Fake GPS – Bump Location (Android)

Dự án Android/Kotlin, không yêu cầu root. Manifest khai báo `ACCESS_MOCK_LOCATION` để Android đưa ứng dụng vào danh sách “Chọn ứng dụng vị trí mô phỏng”; quyền mô phỏng thực tế chỉ có sau khi người dùng tự chọn ứng dụng trong Tùy chọn nhà phát triển. Có hai chế độ:
- Vị trí cố định theo vĩ độ/kinh độ.
- Di chuyển tuyến tính từ điểm đầu đến điểm cuối theo tốc độ km/h.

## Build APK
1. Mở thư mục dự án bằng Android Studio (bản hỗ trợ Android Gradle Plugin 8.7.3).
2. Cài Android SDK 35 nếu Android Studio yêu cầu.
3. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

## Cách bật trên điện thoại
1. Cài APK.
2. Nếu đã cài bản 1.0 trước đây, gỡ bản cũ trước khi cài bản mới (bản debug tạo từ lần chạy GitHub Actions khác có thể có chữ ký khác).
3. Vào Cài đặt > Giới thiệu điện thoại, chạm 7 lần vào Số bản dựng để bật Tùy chọn nhà phát triển (nếu chưa bật).
4. Vào Tùy chọn nhà phát triển > Chọn ứng dụng vị trí mô phỏng (Select mock location app) > chọn Fake GPS – Bump Location.
5. Mở app, nhập tọa độ, bấm Bắt đầu.
6. Để dừng, quay lại app và bấm Dừng giả lập GPS.

## Lưu ý quan trọng
- Bản nguồn đã sửa Manifest để ứng dụng xuất hiện trong danh sách mock-location picker; cần cài APK mới và tự chọn ứng dụng trong Developer Options.
- Chưa biên dịch/xác minh trên thiết bị Android thực tế trong môi trường này.
- Bump có thể phát hiện dữ liệu mock hoặc tự dùng phương thức định vị khác. Không có bảo đảm Bump sẽ chấp nhận vị trí giả lập.
- Ứng dụng chỉ cung cấp cơ chế Mock Location tiêu chuẩn của Android; không vượt qua kiểm tra chống giả mạo của ứng dụng khác.
- Tuyến đường hiện tại là nội suy đường thẳng giữa hai tọa độ, không phải chỉ đường theo mạng lưới đường phố.


## v1.3
Ưu tiên vị trí cố định; bổ sung kiểm tra AppOps mock location và báo lỗi khi Android từ chối cập nhật. Không có chức năng vượt qua cơ chế xác thực vị trí của ứng dụng khác.


## v1.3.1
Sửa nút dừng để gửi ACTION_STOP, xóa cờ duy trì đã lưu trước khi dừng dịch vụ. Điều này tránh việc START_STICKY tự phục hồi cấu hình cũ sau khi người dùng chủ động dừng.
