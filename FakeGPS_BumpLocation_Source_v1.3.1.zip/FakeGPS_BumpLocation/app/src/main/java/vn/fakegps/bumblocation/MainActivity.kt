package vn.fakegps.bumblocation

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.os.Process
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Typeface
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var lat: EditText
    private lateinit var lon: EditText
    private lateinit var endLat: EditText
    private lateinit var endLon: EditText
    private lateinit var speed: EditText
    private lateinit var status: TextView
    private lateinit var current: TextView
    private var receiverRegistered = false
    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == MockLocationService.ACTION_STATUS) {
                status.text = "Trạng thái: " + (intent.getStringExtra("message") ?: "Không rõ")
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter(MockLocationService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(statusReceiver, filter)
        receiverRegistered = true
        refreshPermissionStatus()
    }

    override fun onPause() {
        if (receiverRegistered) { unregisterReceiver(statusReceiver); receiverRegistered = false }
        super.onPause()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNeededPermissions()
        buildUi()
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 10)
    }

    private fun field(hint: String, value: String = ""): EditText =
        EditText(this).apply {
            this.hint = hint
            setSingleLine(true)
            setText(value)
            textSize = 16f
            setPadding(24, 12, 24, 12)
        }

    private fun button(label: String, action: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "FAKE GPS – BUMP LOCATION"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 8)
        }
        content.addView(title)
        content.addView(TextView(this).apply {
            text = "Giả lập GPS để kiểm thử ứng dụng. Android yêu cầu bạn tự chọn ứng dụng này trong Tùy chọn nhà phát triển."
            textSize = 14f
            setPadding(0, 8, 0, 12)
        })
        content.addView(TextView(this).apply { text = "VỊ TRÍ CỐ ĐỊNH"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD })
        lat = field("Vĩ độ (ví dụ: 21.0285)", "21.0285")
        lon = field("Kinh độ (ví dụ: 105.8542)", "105.8542")
        content.addView(lat); content.addView(lon)
        content.addView(button("Bắt đầu tại vị trí cố định") { startFixed() })
        content.addView(TextView(this).apply {
            text = "DI CHUYỂN THEO TUYẾN"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 18, 0, 4)
        })
        endLat = field("Vĩ độ điểm đến", "21.0350")
        endLon = field("Kinh độ điểm đến", "105.8650")
        speed = field("Tốc độ (km/h)", "5")
        content.addView(TextView(this).apply { text = "Điểm xuất phát dùng tọa độ ở phần Vị trí cố định." })
        content.addView(endLat); content.addView(endLon); content.addView(speed)
        content.addView(button("Bắt đầu di chuyển giả lập") { startRoute() })
        content.addView(button("Dừng giả lập GPS") {
            // Use the explicit stop action so the service clears its saved
            // active flag before shutting down; otherwise START_STICKY may
            // restore the previous mock location after a service restart.
            val stopIntent = Intent(this, MockLocationService::class.java).apply {
                action = MockLocationService.ACTION_STOP
            }
            try {
                startService(stopIntent)
                status.text = "Đang gửi lệnh dừng giả lập…"
            } catch (e: Exception) {
                status.text = "Không gửi được lệnh dừng: ${e.message ?: e.javaClass.simpleName}"
            }
        })
        content.addView(button("Mở Tùy chọn nhà phát triển") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        })
        status = TextView(this).apply {
            text = "Trạng thái: Chưa chạy"
            textSize = 15f
            setPadding(0, 16, 0, 8)
        }
        current = TextView(this).apply { text = "Tọa độ đang phát: —"; textSize = 14f }
        content.addView(status)
        content.addView(current)
        content.addView(button("Kiểm tra quyền mock location") { refreshPermissionStatus(true) })
        content.addView(TextView(this).apply {
            text = "Lưu ý: Bump có thể nhận biết vị trí giả lập hoặc từ chối dữ liệu mock. Ứng dụng này không can thiệp hay vượt qua cơ chế chống giả mạo của Bump."
            textSize = 13f
            setPadding(0, 12, 0, 20)
        })
        scroll.addView(content)
        outer.addView(scroll)
        setContentView(outer)
    }

    private fun read(edit: EditText): Double? = edit.text.toString().trim().toDoubleOrNull()

    private fun validLat(v: Double?) = v != null && v in -90.0..90.0
    private fun validLon(v: Double?) = v != null && v in -180.0..180.0

    private fun mockLocationAllowed(): Boolean = try {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        ops.checkOpNoThrow(AppOpsManager.OPSTR_MOCK_LOCATION, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) { false }

    private fun refreshPermissionStatus(showToast: Boolean = false) {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        status.text = when {
            !fine -> "Trạng thái: Chưa cấp quyền vị trí chính xác"
            !mockLocationAllowed() -> "Trạng thái: Chưa chọn FakeGPS trong Tùy chọn nhà phát triển"
            else -> "Trạng thái: Quyền vị trí và mock location đã được cấp"
        }
        if (showToast) toast(status.text.toString())
    }

    private fun startFixed() {
        val a = read(lat); val b = read(lon)
        if (!validLat(a) || !validLon(b)) { toast("Vui lòng nhập tọa độ hợp lệ."); return }
        launchService(MockLocationService.ACTION_FIXED, a!!, b!!, 0.0, 0.0, 0.0)
    }

    private fun startRoute() {
        val a = read(lat); val b = read(lon); val c = read(endLat); val d = read(endLon)
        val s = read(speed)
        if (!validLat(a) || !validLon(b) || !validLat(c) || !validLon(d) || s == null || s <= 0.0 || s > 300.0) {
            toast("Kiểm tra tọa độ và tốc độ (0–300 km/h)."); return
        }
        launchService(MockLocationService.ACTION_ROUTE, a!!, b!!, c!!, d!!, s)
    }

    private fun launchService(action: String, a: Double, b: Double, c: Double, d: Double, s: Double) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            toast("Cần cấp quyền vị trí chính xác."); requestNeededPermissions(); return
        }
        if (!mockLocationAllowed()) {
            toast("Chưa chọn FakeGPS làm ứng dụng vị trí mô phỏng trong Tùy chọn nhà phát triển.")
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            return
        }
        val i = Intent(this, MockLocationService::class.java).apply {
            this.action = action
            putExtra("lat", a); putExtra("lon", b)
            putExtra("endLat", c); putExtra("endLon", d); putExtra("speed", s)
        }
        ContextCompat.startForegroundService(this, i)
        status.text = "Trạng thái: Đang khởi động dịch vụ…"
        current.text = "Tọa độ yêu cầu: %.6f, %.6f".format(a, b)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
