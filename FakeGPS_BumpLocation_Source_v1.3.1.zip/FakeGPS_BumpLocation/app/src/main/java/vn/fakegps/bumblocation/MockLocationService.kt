package vn.fakegps.bumblocation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.*

/**
 * Foreground mock-location service. It keeps publishing while the Activity is
 * not visible. START_STICKY + saved settings allow Android to recreate it if
 * the process is reclaimed; force-stop, reboot, permission revocation, or OEM
 * task-killer policies can still stop it.
 */
class MockLocationService : Service() {
    private lateinit var lm: LocationManager
    private lateinit var prefs: SharedPreferences
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private var task: ScheduledFuture<*>? = null
    private var startTime = 0L
    private var durationSeconds = 1.0
    private var startLat = 0.0
    private var startLon = 0.0
    private var targetLat = 0.0
    private var targetLon = 0.0
    private var fixed = true

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
            stopMockProvider()
            sendStatus("Đã dừng giả lập GPS theo yêu cầu")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            // Must remain a foreground service while location is being simulated.
            startForeground(NOTIFICATION_ID, notification("Đang duy trì vị trí mô phỏng"))
            if (intent != null && (intent.action == ACTION_FIXED || intent.action == ACTION_ROUTE)) {
                startLat = intent.getDoubleExtra("lat", 21.0285)
                startLon = intent.getDoubleExtra("lon", 105.8542)
                targetLat = intent.getDoubleExtra("endLat", startLat)
                targetLon = intent.getDoubleExtra("endLon", startLon)
                val speed = intent.getDoubleExtra("speed", 0.0)
                fixed = intent.action != ACTION_ROUTE
                if (!validCoordinate(startLat, startLon) || !validCoordinate(targetLat, targetLon)) {
                    throw IllegalArgumentException("Tọa độ không hợp lệ")
                }
                durationSeconds = if (!fixed && speed > 0.0) {
                    max(1.0, distanceMeters(startLat, startLon, targetLat, targetLon) / (speed / 3.6))
                } else 1.0
                prefs.edit()
                    .putBoolean(KEY_ACTIVE, true)
                    .putBoolean(KEY_FIXED, fixed)
                    .putFloat(KEY_START_LAT, startLat.toFloat())
                    .putFloat(KEY_START_LON, startLon.toFloat())
                    .putFloat(KEY_END_LAT, targetLat.toFloat())
                    .putFloat(KEY_END_LON, targetLon.toFloat())
                    .putFloat(KEY_SPEED, speed.toFloat())
                    .apply()
                startTime = SystemClock.elapsedRealtime()
            } else {
                // Android recreated a sticky service with a null Intent.
                if (!prefs.getBoolean(KEY_ACTIVE, false)) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return START_NOT_STICKY
                }
                restoreSavedSettings()
            }

            installMockProvider()
            task?.cancel(true)
            task = executor.scheduleAtFixedRate({ publishLocation() }, 0, 1000, TimeUnit.MILLISECONDS)
            sendStatus(if (fixed) "Đang duy trì vị trí cố định liên tục" else "Đang duy trì vị trí di chuyển; đến đích sẽ giữ nguyên")
            updateNotification(if (fixed) "Đang duy trì vị trí cố định" else "Đang duy trì vị trí mô phỏng")
            return START_STICKY
        } catch (e: Exception) {
            prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
            sendStatus(if (e is SecurityException) {
                "Android từ chối quyền mock location. Kiểm tra Developer Options và quyền vị trí."
            } else {
                "Không thể duy trì GPS mô phỏng: ${e.message ?: e.javaClass.simpleName}"
            })
            stopMockProvider()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
    }

    private fun restoreSavedSettings() {
        startLat = prefs.getFloat(KEY_START_LAT, 21.0285f).toDouble()
        startLon = prefs.getFloat(KEY_START_LON, 105.8542f).toDouble()
        targetLat = prefs.getFloat(KEY_END_LAT, startLat.toFloat()).toDouble()
        targetLon = prefs.getFloat(KEY_END_LON, startLon.toFloat()).toDouble()
        fixed = prefs.getBoolean(KEY_FIXED, true)
        val speed = prefs.getFloat(KEY_SPEED, 0f).toDouble()
        if (!validCoordinate(startLat, startLon) || !validCoordinate(targetLat, targetLon)) {
            throw IllegalStateException("Cấu hình vị trí đã lưu không hợp lệ")
        }
        durationSeconds = if (!fixed && speed > 0.0) {
            max(1.0, distanceMeters(startLat, startLon, targetLat, targetLon) / (speed / 3.6))
        } else 1.0
        // On process recreation, resume from the saved start point.
        startTime = SystemClock.elapsedRealtime()
    }

    @Suppress("DEPRECATION")
    private fun installMockProvider() {
        try { lm.removeTestProvider(LocationManager.GPS_PROVIDER) } catch (_: Exception) {}
        lm.addTestProvider(
            LocationManager.GPS_PROVIDER, false, false, false, false,
            true, true, true, Criteria.POWER_HIGH, Criteria.ACCURACY_FINE
        )
        lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true)
    }

    private fun publishLocation() {
        try {
            val fraction = if (fixed) 0.0 else {
                ((SystemClock.elapsedRealtime() - startTime) / 1000.0 / durationSeconds).coerceIn(0.0, 1.0)
            }
            val latitude = startLat + (targetLat - startLat) * fraction
            val longitude = startLon + (targetLon - startLon) * fraction
            val loc = Location(LocationManager.GPS_PROVIDER).apply {
                this.latitude = latitude
                this.longitude = longitude
                accuracy = 4f
                altitude = 10.0
                bearing = if (fixed) 0f else bearingTo(startLat, startLon, targetLat, targetLon)
                speed = if (fixed || fraction >= 1.0) 0f else (distanceMeters(startLat, startLon, targetLat, targetLon) / durationSeconds).toFloat()
                time = System.currentTimeMillis()
                elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            }
            lm.setTestProviderLocation(LocationManager.GPS_PROVIDER, loc)
        } catch (e: SecurityException) {
            prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
            sendStatus("Android đã thu hồi/từ chối quyền mock location; dịch vụ phải dừng")
            stopSelf()
        } catch (e: Exception) {
            prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
            sendStatus("Lỗi cập nhật vị trí mô phỏng: ${e.message ?: e.javaClass.simpleName}")
            stopSelf()
        }
    }

    private fun validCoordinate(a: Double, b: Double) =
        a.isFinite() && b.isFinite() && a in -90.0..90.0 && b in -180.0..180.0

    private fun sendStatus(message: String) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra("message", message))
    }

    private fun stopMockProvider() {
        task?.cancel(true)
        try {
            lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, false)
            lm.removeTestProvider(LocationManager.GPS_PROVIDER)
        } catch (_: Exception) {}
    }

    private fun distanceMeters(a: Double, b: Double, c: Double, d: Double): Double {
        val r = 6371000.0
        val p1 = Math.toRadians(a); val p2 = Math.toRadians(c)
        val dp = Math.toRadians(c - a); val dl = Math.toRadians(d - b)
        val h = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * r * asin(sqrt(h))
    }

    private fun bearingTo(a: Double, b: Double, c: Double, d: Double): Float {
        val p1 = Math.toRadians(a); val p2 = Math.toRadians(c); val dl = Math.toRadians(d - b)
        return ((Math.toDegrees(atan2(sin(dl) * cos(p2), cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl))) + 360) % 360).toFloat()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Fake GPS", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Fake GPS – Bump Location")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true).build()
    }

    private fun updateNotification(message: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification(message))
    }

    override fun onDestroy() {
        stopMockProvider()
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_FIXED = "vn.fakegps.FIXED"
        const val ACTION_ROUTE = "vn.fakegps.ROUTE"
        const val ACTION_STOP = "vn.fakegps.STOP"
        const val ACTION_STATUS = "vn.fakegps.STATUS"
        private const val CHANNEL = "fake_gps_channel"
        private const val NOTIFICATION_ID = 7
        private const val PREFS = "mock_location_state"
        private const val KEY_ACTIVE = "active"
        private const val KEY_FIXED = "fixed"
        private const val KEY_START_LAT = "start_lat"
        private const val KEY_START_LON = "start_lon"
        private const val KEY_END_LAT = "end_lat"
        private const val KEY_END_LON = "end_lon"
        private const val KEY_SPEED = "speed"
    }
}
