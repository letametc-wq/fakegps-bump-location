package vn.fakegps.bumblocation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.*

class MockLocationService : Service() {
    private lateinit var lm: LocationManager
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private var task: ScheduledFuture<*>? = null
    private var startTime = 0L
    private var durationSeconds = 1.0
    private var startLat = 0.0
    private var startLon = 0.0
    private var targetLat = 0.0
    private var targetLon = 0.0
    private var fixed = true

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startForeground(7, notification("Đang chuẩn bị giả lập GPS"))
        try {
            startLat = intent?.getDoubleExtra("lat", 21.0285) ?: 21.0285
            startLon = intent?.getDoubleExtra("lon", 105.8542) ?: 105.8542
            targetLat = intent?.getDoubleExtra("endLat", startLat) ?: startLat
            targetLon = intent?.getDoubleExtra("endLon", startLon) ?: startLon
            val speed = intent?.getDoubleExtra("speed", 0.0) ?: 0.0
            fixed = intent?.action != ACTION_ROUTE
            durationSeconds = if (speed > 0) max(1.0, distanceMeters(startLat, startLon, targetLat, targetLon) / (speed / 3.6)) else 1.0
            startTime = SystemClock.elapsedRealtime()
            installMockProvider()
            task?.cancel(true)
            task = executor.scheduleAtFixedRate({ publishLocation() }, 0, 1000, TimeUnit.MILLISECONDS)
        } catch (e: Exception) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun installMockProvider() {
        try { lm.removeTestProvider(LocationManager.GPS_PROVIDER) } catch (_: Exception) {}
        lm.addTestProvider(
            LocationManager.GPS_PROVIDER, false, false, false, false,
            true, true, true, Criteria.POWER_HIGH, Criteria.ACCURACY_FINE
        )
        lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true)
    }

    private fun publishLocation() {
        try {
            val fraction = if (fixed) 0.0 else ((SystemClock.elapsedRealtime() - startTime) / 1000.0 / durationSeconds).coerceIn(0.0, 1.0)
            val lat = startLat + (targetLat - startLat) * fraction
            val lon = startLon + (targetLon - startLon) * fraction
            val loc = Location(LocationManager.GPS_PROVIDER).apply {
                latitude = lat
                longitude = lon
                accuracy = 4f
                altitude = 10.0
                bearing = if (fixed) 0f else bearingTo(startLat, startLon, targetLat, targetLon)
                speed = if (fixed) 0f else (distanceMeters(startLat, startLon, targetLat, targetLon) / durationSeconds).toFloat()
                time = System.currentTimeMillis()
                elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            }
            lm.setTestProviderLocation(LocationManager.GPS_PROVIDER, loc)
            if (!fixed && fraction >= 1.0) {
                // Hold at the destination until the user stops the service.
            }
        } catch (_: SecurityException) {
            stopSelf()
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun distanceMeters(a: Double, b: Double, c: Double, d: Double): Double {
        val r = 6371000.0
        val p1 = Math.toRadians(a); val p2 = Math.toRadians(c)
        val dp = Math.toRadians(c - a); val dl = Math.toRadians(d - b)
        val h = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * r * asin(sqrt(h))
    }

    private fun bearingTo(a: Double, b: Double, c: Double, d: Double): Float {
        val p1 = Math.toRadians(a); val p2 = Math.toRadians(c); val dl = Math.toRadians(d - b)
        return ((Math.toDegrees(atan2(sin(dl) * cos(p2), cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl))) + 360) % 360).toFloat()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Fake GPS", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Fake GPS – Bump Location")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true).build()
    }

    override fun onDestroy() {
        task?.cancel(true)
        try { lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, false); lm.removeTestProvider(LocationManager.GPS_PROVIDER) } catch (_: Exception) {}
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_FIXED = "vn.fakegps.FIXED"
        const val ACTION_ROUTE = "vn.fakegps.ROUTE"
        const val ACTION_STOP = "vn.fakegps.STOP"
        private const val CHANNEL = "fake_gps_channel"
    }
}
