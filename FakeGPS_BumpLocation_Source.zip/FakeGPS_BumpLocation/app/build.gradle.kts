plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "vn.fakegps.bumblocation"
    compileSdk = 35
    defaultConfig {
        applicationId = "vn.fakegps.bumblocation"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
