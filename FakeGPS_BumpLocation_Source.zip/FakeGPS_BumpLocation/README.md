# Fake GPS – Bump Location (Android)

Dự án mẫu Android/Kotlin, không yêu cầu root. Có hai chế độ:
- Vị trí cố định theo vĩ độ/kinh độ.
- Di chuyển tuyến tính từ điểm đầu đến điểm cuối theo tốc độ km/h.

## Build APK
1. Mở thư mục dự án bằng Android Studio (bản hỗ trợ Android Gradle Plugin 8.7.3).
2. Cài Android SDK 35 nếu Android Studio yêu cầu.
3. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

## Cách bật trên điện thoại
1. Cài APK.
2. Vào Cài đặt > Giới thiệu điện thoại, chạm 7 lần vào Số bản dựng để bật Tùy chọn nhà phát triển (nếu chưa bật).
3. Vào Tùy chọn nhà phát triển > Chọn ứng dụng vị trí mô phỏng (Select mock location app) > chọn Fake GPS – Bump Location.
4. Mở app, nhập tọa độ, bấm Bắt đầu.
5. Để dừng, quay lại app và bấm Dừng giả lập GPS.

## Lưu ý quan trọng
- Đây là dự án mã nguồn; môi trường tạo tệp hiện tại không có Android SDK/Gradle nên chưa thể biên dịch và xác minh APK tại đây.
- Bump có thể phát hiện dữ liệu mock hoặc tự dùng phương thức định vị khác. Không có bảo đảm Bump sẽ chấp nhận vị trí giả lập.
- Ứng dụng chỉ cung cấp cơ chế Mock Location tiêu chuẩn của Android; không vượt qua kiểm tra chống giả mạo của ứng dụng khác.
- Tuyến đường hiện tại là nội suy đường thẳng giữa hai tọa độ, không phải chỉ đường theo mạng lưới đường phố.
